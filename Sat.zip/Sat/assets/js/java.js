var menu;
var hamburgerHTML;
var hamburgerMenu;
var menuHidden;


window.onload = function () {
    menu = document.getElementById("menu");
    hamburgerMenu = document.getElementById("hamburger-menu");
    hamburgerHTML = hamburgerMenu.innerHTML;
    menuHidden = true;
}


function showNavMenu() {
    if (menuHidden) {
        hamburgerMenu.innerHTML = menu.innerHTML;
        menuHidden = false;
    } else {
        hamburgerMenu.innerHTML = hamburgerHTML;
        menuHidden = true;
    }
}